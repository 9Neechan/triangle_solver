#!/bin/sh -xe

./pkg/snap/build.sh --use-lxd
