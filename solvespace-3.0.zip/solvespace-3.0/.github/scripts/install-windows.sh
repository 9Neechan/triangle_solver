#!/bin/sh -xe

git submodule update --init
