### System information

- **SolveSpace version:** <!--e.g. 3.0~3dd2fc00; go to Help → About...-->
- **Operating system:** <!--e.g. Debian testing-->

### Expected behavior

<!--What should have happened?-->

### Actual behavior

<!--What actually happened?-->

### Additional information

<!--For bugs, please attach a savefile that shows the problematic behavior.
You can attach `.slvs` files by archiving them into a `.zip` first.-->
